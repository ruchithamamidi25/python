from flask import Flask,render_template,request
from flask_cors import CORS

app=Flask(__name__)
CORS(app)
@app.route('/',methods=['GET'])
def home():
    return render_template('index.html',response='hello world')

@app.route('/about',methods=['GET'])
def inner_page():
    return render_template('inner_page.html')

@app.route('/portfolio_details',methods=['GET'])
def portfolio_details():
    return render_template('portfolio_details.html')



@app.route('/login-form',methods=['POST'])
def login_form():
    name = request.form['name']
    phone = request.form['phone']
    # return [name,phone]
    return render_template('response.html',response=[name,phone])
 
 
@app.route('/login',methods=['GET'])
def login():
    return render_template('login.html')


if __name__=='__main__':
    app.run(debug=True)